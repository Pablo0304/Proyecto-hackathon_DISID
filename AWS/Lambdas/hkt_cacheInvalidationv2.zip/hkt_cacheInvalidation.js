const { CloudFrontClient, CreateInvalidationCommand, ListInvalidationsCommand } = require('@aws-sdk/client-cloudfront');

exports.handler = async function () {
    console.log("Evento recibido:");

    const client = new CloudFrontClient({
        region: "us-east-1"
    });
    const input = {
        DistributionId: process.env.CLOUDFRONT_DISTRIBUTION_ID,
        InvalidationBatch: {
            Paths: {
                Quantity: 1,
                Items: [
                    "/*",
                ],
            },
            CallerReference: `my-invalidation-${Date.now()}`,
        },
    };

    try {
        const listCommand = new ListInvalidationsCommand({
            DistributionId: process.env.CLOUDFRONT_DISTRIBUTION_ID
        });
        const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
        await sleep(5000);
        const listResponse = await client.send(listCommand);
        let check = true;
        listResponse.InvalidationList.Items?.forEach(invalidation => {
            if (invalidation.Status === 'InProgress') {
                check = false;
                return;
            }
        });
        if (check) {
            const command = new CreateInvalidationCommand(input);
            const response = client.send(command);
            console.log("Invalidación de CloudFront creada:", command);
            console.log("Respuesta:", response);
        }
    } catch (error) {
        console.error("Error al crear la invalidación de CloudFront:", error);
        throw error;
    }
};