const https = require('https');
const fs = require('fs');
const path = require('path');
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const mime = require('mime-types');
const AdmZip = require('adm-zip');

exports.handler = async () => {
    const url = 'https://gitlab.com/api/v4/projects/frolyak.ivn%2Fmerge-path-app/repository/archive.zip';
    const token = 'glpat-uq1UTCyMr5Z3yd52RyDT';
    const s3 = new S3Client({ region: "us-east-1" });
    const bucketName = 'hkt-pre-mergepath-webapp';

    async function uploadFile(filePath, key) {
        try {
            const contentType = mime.lookup(filePath);
            const stream = fs.createReadStream(filePath);
            const uploadParams = {
                Bucket: bucketName,
                Key: key,
                Body: stream,
                ContentType: contentType
            };
            const command = new PutObjectCommand(uploadParams);
            await s3.send(command);
            console.log(`Archivo subido: ${key}`);
        } catch (err) {
            console.error("Error al subir el archivo:", err);
            throw err;
        }
    }

    async function uploadDirectory(directory, prefix = '') {
        const files = fs.readdirSync(directory);

        for (const file of files) {
            const filePath = path.join(directory, file);
            const fileStat = fs.statSync(filePath);

            if (fileStat.isFile()) {
                const key = path.join(prefix, file);
                await uploadFile(filePath, key);
            } else if (fileStat.isDirectory()) {
                const newPrefix = path.join(prefix, file);
                await uploadDirectory(filePath, newPrefix);
            }
        }
    }

    return new Promise((resolve, reject) => {
        https.get(url, {
            headers: {
                'PRIVATE-TOKEN': token
            }
        }, (res) => {
            const filePath = '/tmp/repo.zip';
            const stream = fs.createWriteStream(filePath);

            res.pipe(stream);

            stream.on('finish', async () => {
                try {
                    const zip = new AdmZip('/tmp/repo.zip');
                    zip.extractAllTo('/tmp/', true);
                    console.log('Descompresión completada.');
                } catch (err) {
                    console.error('Error al descomprimir:', err);
                }
                fs.readdir('/tmp/', async (err, files) => {
                    if (err) {
                        console.error('Error leyendo el directorio', err);
                        reject(err);
                    } else {
                        const nombreRepo = files.filter(file => fs.statSync(path.join('/tmp', file)).isDirectory())[0];
                        try {
                            const newPath = `/tmp/${nombreRepo}`;
                            await uploadDirectory(newPath);
                            resolve();
                        } catch (uploadError) {
                            console.error('Error subiendo el directorio', uploadError);
                            reject(uploadError);
                        }
                    }
                });
            });
        }).on('error', reject);
    });
}